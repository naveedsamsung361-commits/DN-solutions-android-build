-- DN Solutions Machine Operations Hub: shared workspace table
-- Run in Supabase SQL Editor for the project used by cloud-config.js.
-- Create user accounts in Supabase Auth as administrator; disable public sign-ups.
create table if not exists public.dn_ops_workspace (
  workspace_id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
alter table public.dn_ops_workspace enable row level security;

-- For a single private workshop where every provisioned account is authorized
-- to read/write the shared workspace. Do not enable public sign-ups.
drop policy if exists "authenticated users read operations workspace" on public.dn_ops_workspace;
create policy "authenticated users read operations workspace"
  on public.dn_ops_workspace for select to authenticated using (true);

drop policy if exists "authenticated users insert operations workspace" on public.dn_ops_workspace;
create policy "authenticated users insert operations workspace"
  on public.dn_ops_workspace for insert to authenticated with check (true);

drop policy if exists "authenticated users update operations workspace" on public.dn_ops_workspace;
create policy "authenticated users update operations workspace"
  on public.dn_ops_workspace for update to authenticated using (true) with check (true);

grant select, insert, update on public.dn_ops_workspace to authenticated;
